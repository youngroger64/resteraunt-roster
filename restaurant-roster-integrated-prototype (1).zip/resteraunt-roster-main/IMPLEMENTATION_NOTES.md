# Staff roster workflow implementation

This branch adds the first integrated employee scheduling workflow to the roster sandbox.

## Added

- Manager-approved **Normal week** rules (target hours, target days, preferred area).
- Dated employee availability exceptions; these are hard constraints for candidate selection.
- Employee-facing `/rosters/staff/` page modelled on the clocking app layout.
- Upcoming published roster view (five-week horizon).
- Shift confirmation and **Can't work** response.
- Manager replacement suggestions for Can't work requests; shifts remain assigned until approved.
- Open-shift requests with manager approval/decline.
- Session-only clock UI preview for testing the combined Clock / Roster experience. It deliberately writes no attendance/payroll records.
- Multiple weeks can remain published so upcoming rosters remain visible.

## Deploy to the roster test VM

```bash
cd <roster-project>
source <venv>/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py test apps.roster
python manage.py collectstatic --noinput  # production only
```

Restart the existing gunicorn/systemd service after migration.

## Test staff access

Employees identify with `Employee.external_id` on `/rosters/staff/` in this sandbox. This is intentionally a temporary bridge to the employee number used by the clocking app. Do not treat it as production authentication; use the clocking app's stronger employee identity/PIN flow when the projects are integrated.

## Recommended next integration step

Do not duplicate attendance models into this project. Move or expose the live clocking service behind the staff page so the Clock tab calls the real clock service, while roster data remains owned by the roster module. Employee identity should be shared by a stable external employee ID.
